# tsParticles Fireworks 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/matteobruni/pen/abJQrbK](https://codepen.io/matteobruni/pen/abJQrbK).

