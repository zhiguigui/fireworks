# tsParticles Fireworks with sounds - 2.7.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/matteobruni/pen/MWBwGEz](https://codepen.io/matteobruni/pen/MWBwGEz).

tsParticles new Fireworks preset with sounds using the version 2.7.0 with the sounds plugin