# fireworks seen in the countryside

A Pen created on CodePen.io. Original URL: [https://codepen.io/K-T/pen/NjyNQy](https://codepen.io/K-T/pen/NjyNQy).

